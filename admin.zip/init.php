<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'db.php';

// 清空所有表
$tables = array('crawler_tasks', 'query_results');
foreach ($tables as $table) {
    $conn->query("DROP TABLE IF EXISTS `$table`");
}

// 创建crawler_tasks表
$sql = "CREATE TABLE IF NOT EXISTS `crawler_tasks` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `steps` TEXT NOT NULL COMMENT 'JSON格式的步骤配置',
    `output_template` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "表 crawler_tasks 创建成功<br>";
} else {
    echo "创建表错误: " . $conn->error . "<br>";
}

// 创建query_results表
$sql = "CREATE TABLE IF NOT EXISTS `query_results` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `task_id` INT NOT NULL,
    `input` VARCHAR(255) NOT NULL,
    `output` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`task_id`) REFERENCES `crawler_tasks`(`id`)
)";

if ($conn->query($sql) === TRUE) {
    echo "表 query_results 创建成功<br>";
} else {
    echo "创建表错误: " . $conn->error . "<br>";
}

// 添加示例任务
$example_task = array(
    'name' => '示例图书查询',
    'description' => '查询图书信息 - 需要两步请求',
    'steps' => array(
        array(
            'name' => 'search',
            'url' => 'https://api.example.com/search?q={{input}}',
            'method' => 'GET',
            'headers' => array(
                'Accept' => 'application/json'
            ),
            'body' => '',
            'extract_rules' => array(
                'book_id' => array(
                    'type' => 'regex',
                    'pattern' => '/"id":"(\d+)"/'
                )
            )
        ),
        array(
            'name' => 'details',
            'url' => 'https://api.example.com/books/{{search.book_id}}',
            'method' => 'GET',
            'headers' => array(
                'Accept' => 'application/json'
            ),
            'body' => '',
            'extract_rules' => array(
                'title' => array(
                    'type' => 'regex',
                    'pattern' => '/"title":"([^"]+)"/'
                ),
                'author' => array(
                    'type' => 'regex',
                    'pattern' => '/"author":"([^"]+)"/'
                )
            )
        )
    ),
    'output_template' => '书名: {{details.title}}, 作者: {{details.author}}'
);

// 正确转义所有值
$steps_json = $conn->real_escape_string(json_encode($example_task['steps']));
$output_template = $conn->real_escape_string($example_task['output_template']);
$name = $conn->real_escape_string($example_task['name']);
$description = $conn->real_escape_string($example_task['description']);

$sql = "INSERT INTO crawler_tasks (name, description, steps, output_template) 
        VALUES ('$name', '$description', '$steps_json', '$output_template')";

if ($conn->query($sql)) {
    echo "示例任务添加成功<br>";
} else {
    echo "添加任务失败: " . $conn->error . "<br>";
}

echo "<h2>数据库初始化完成!</h2>";
echo "<a href='admin.php'>进入后台管理</a>";

$conn->close();
?>