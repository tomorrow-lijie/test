<?php
$servername = "localhost";
$username = "rootadmin";
$password = "123456";
$dbname = "sjk";

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}
?>