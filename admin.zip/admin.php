<?php
require_once 'functions.php';

// 处理初始化请求
if (isset($_GET['init'])) {
    header("Location: init.php");
    exit;
}

// 获取所有任务
$tasks = array();
$sql = "SELECT * FROM crawler_tasks";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }
}

// 处理任务保存
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_task'])) {
        // 删除任务
        $task_id = intval($_POST['task_id']);
        $delete_sql = "DELETE FROM crawler_tasks WHERE id = $task_id";
        $conn->query($delete_sql);
        header("Location: admin.php");
        exit;
    } else {
        // 保存任务
        $name = $conn->real_escape_string($_POST['name']);
        $description = $conn->real_escape_string($_POST['description']);
        $output_template = $conn->real_escape_string($_POST['output_template']);
        
        // 处理步骤
        $steps = array();
        if (isset($_POST['step_name'])) {
            $step_count = count($_POST['step_name']);
            for ($i = 0; $i < $step_count; $i++) {
                $step = array(
                    'name' => $_POST['step_name'][$i],
                    'url' => $_POST['step_url'][$i],
                    'method' => $_POST['step_method'][$i],
                    'headers' => array(),
                    'body' => $_POST['step_body'][$i],
                    'extract_rules' => array()
                );
                
                // 处理请求头
                if (!empty($_POST['step_header_key'][$i])) {
                    foreach ($_POST['step_header_key'][$i] as $key => $header_key) {
                        $header_value = $_POST['step_header_value'][$i][$key];
                        if (!empty($header_key)) {
                            $step['headers'][$header_key] = $header_value;
                        }
                    }
                }
                
                // 处理提取规则
                if (!empty($_POST['step_rule_key'][$i])) {
                    foreach ($_POST['step_rule_key'][$i] as $key => $rule_key) {
                        $rule_pattern = $_POST['step_rule_pattern'][$i][$key];
                        if (!empty($rule_key)) {
                            $step['extract_rules'][$rule_key] = array(
                                'type' => 'regex',
                                'pattern' => $rule_pattern
                            );
                        }
                    }
                }
                
                $steps[] = $step;
            }
        }
        
        $steps_json = $conn->real_escape_string(json_encode($steps));
        
        if (isset($_POST['task_id'])) {
            // 更新现有任务
            $task_id = intval($_POST['task_id']);
            $update_sql = "UPDATE crawler_tasks 
                           SET name = '$name', description = '$description', 
                               steps = '$steps_json', output_template = '$output_template'
                           WHERE id = $task_id";
            $conn->query($update_sql);
        } else {
            // 创建新任务
            $insert_sql = "INSERT INTO crawler_tasks (name, description, steps, output_template) 
                           VALUES ('$name', '$description', '$steps_json', '$output_template')";
            $conn->query($insert_sql);
        }
        
        header("Location: admin.php");
        exit;
    }
}

// 获取要编辑的任务
$edit_task = null;
if (isset($_GET['edit'])) {
    $task_id = intval($_GET['edit']);
    $sql = "SELECT * FROM crawler_tasks WHERE id = $task_id";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $edit_task = $result->fetch_assoc();
        $edit_task['steps'] = json_decode($edit_task['steps'], true);
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台管理 - 爬虫任务配置</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            box-shadow: 3px 0 10px rgba(0, 0, 0, 0.1);
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 5px;
            margin-bottom: 5px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #3498db;
            color: white;
        }
        .main-content {
            padding: 30px;
        }
        .step-card {
            border-left: 4px solid #3498db;
            margin-bottom: 20px;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }
        .step-card .card-header {
            background: #e3f2fd;
            font-weight: bold;
        }
        .header-row, .rule-row {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            border: 1px solid #eee;
        }
        .preview-box {
            background: #2c3e50;
            color: #ecf0f1;
            border-radius: 8px;
            padding: 15px;
            max-height: 200px;
            overflow: auto;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- 侧边栏 -->
            <div class="col-md-2 col-lg-2 sidebar p-0">
                <div class="p-3">
                    <h3 class="mb-4 text-center pt-3">爬虫管理系统</h3>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <i class="bi bi-list-task me-2"></i> 任务管理
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="bi bi-search me-2"></i> 前台查询
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="admin.php?init=1">
                                <i class="bi bi-database me-2"></i> 初始化数据库
                            </a>
                        </li>
                        <li class="nav-item mt-4">
                            <a class="nav-link" href="#">
                                <i class="bi bi-gear me-2"></i> 系统设置
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="bi bi-question-circle me-2"></i> 帮助文档
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- 主内容区 -->
            <div class="col-md-10 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1><i class="bi bi-robot me-2"></i>爬虫任务管理</h1>
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                        <i class="bi bi-plus-circle me-1"></i> 添加新任务
                    </button>
                </div>
                
                <!-- 任务列表 -->
                <div class="card shadow mb-4">
                    <div class="card-header bg-primary text-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h3 class="mb-0">爬虫任务列表</h3>
                            <span class="badge bg-light text-dark"><?= count($tasks) ?> 个任务</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (empty($tasks)): ?>
                            <div class="alert alert-info text-center">
                                <h4 class="mb-3"><i class="bi bi-info-circle"></i> 没有任务</h4>
                                <p>点击右上角的"添加新任务"按钮创建您的第一个爬虫任务</p>
                                <a href="admin.php?init=1" class="btn btn-warning mt-2">
                                    <i class="bi bi-database"></i> 初始化数据库
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>任务名称</th>
                                            <th>描述</th>
                                            <th>步骤数</th>
                                            <th>创建时间</th>
                                            <th>操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($tasks as $task): ?>
                                            <tr>
                                                <td><?= $task['id'] ?></td>
                                                <td>
                                                    <strong><?= htmlspecialchars($task['name']) ?></strong>
                                                </td>
                                                <td><?= htmlspecialchars(substr($task['description'], 0, 50) . (strlen($task['description']) > 50 ? '...' : '')) ?></td>
                                                <td>
                                                    <span class="badge bg-primary">
                                                        <?= count(json_decode($task['steps'], true)) ?>
                                                    </span>
                                                </td>
                                                <td><?= $task['created_at'] ?></td>
                                                <td>
                                                    <a href="admin.php?edit=<?= $task['id'] ?>" class="btn btn-sm btn-primary">
                                                        <i class="bi bi-pencil"></i> 编辑
                                                    </a>
                                                    <form method="POST" style="display:inline;">
                                                        <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                                                        <button type="submit" name="delete_task" class="btn btn-sm btn-danger" 
                                                                onclick="return confirm('确定删除此任务吗？')">
                                                            <i class="bi bi-trash"></i> 删除
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- 任务编辑表单 -->
                <?php if ($edit_task): ?>
                    <div class="card shadow mt-4">
                        <div class="card-header bg-info text-white">
                            <h3 class="mb-0"><i class="bi bi-pencil-square me-2"></i>编辑任务: <?= htmlspecialchars($edit_task['name']) ?></h3>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="task_id" value="<?= $edit_task['id'] ?>">
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">任务名称</label>
                                        <input type="text" class="form-control" name="name" 
                                               value="<?= htmlspecialchars($edit_task['name']) ?>" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">创建时间</label>
                                        <input type="text" class="form-control" 
                                               value="<?= htmlspecialchars($edit_task['created_at']) ?>" disabled>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">任务描述</label>
                                    <textarea class="form-control" name="description" rows="2"><?= htmlspecialchars($edit_task['description']) ?></textarea>
                                </div>
                                
                                <h4 class="mt-4 mb-3 border-bottom pb-2">
                                    <i class="bi bi-diagram-3 me-2"></i>任务步骤配置
                                </h4>
                                <div id="stepsContainer">
                                    <?php foreach ($edit_task['steps'] as $index => $step): ?>
                                        <div class="step-card card">
                                            <div class="card-header d-flex justify-content-between align-items-center">
                                                <h5 class="mb-0">步骤 <?= $index + 1 ?>: <?= htmlspecialchars($step['name']) ?></h5>
                                                <button type="button" class="btn btn-sm btn-danger remove-step">
                                                    <i class="bi bi-trash"></i> 删除
                                                </button>
                                            </div>
                                            <div class="card-body">
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label class="form-label">步骤名称</label>
                                                        <input type="text" class="form-control" 
                                                               name="step_name[]" 
                                                               value="<?= htmlspecialchars($step['name']) ?>" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">URL</label>
                                                        <input type="text" class="form-control" 
                                                               name="step_url[]" 
                                                               value="<?= htmlspecialchars($step['url']) ?>" required>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">HTTP方法</label>
                                                        <select class="form-select" name="step_method[]">
                                                            <option value="GET" <?= $step['method'] === 'GET' ? 'selected' : '' ?>>GET</option>
                                                            <option value="POST" <?= $step['method'] === 'POST' ? 'selected' : '' ?>>POST</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-md-9">
                                                        <label class="form-label">请求体 (POST)</label>
                                                        <textarea class="form-control" name="step_body[]" rows="2"><?= htmlspecialchars($step['body']) ?></textarea>
                                                    </div>
                                                    
                                                    <div class="col-md-12">
                                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                                            <h6 class="mb-0">请求头</h6>
                                                            <button type="button" class="btn btn-sm btn-outline-primary add-header" data-step-index="<?= $index ?>">
                                                                <i class="bi bi-plus"></i> 添加请求头
                                                            </button>
                                                        </div>
                                                        <div class="headers-container mb-3">
                                                            <?php foreach ($step['headers'] as $key => $value): ?>
                                                                <div class="row g-2 mb-2 header-row">
                                                                    <div class="col-md-5">
                                                                        <input type="text" class="form-control" 
                                                                               name="step_header_key[<?= $index ?>][]" 
                                                                               placeholder="Header Key" 
                                                                               value="<?= htmlspecialchars($key) ?>">
                                                                    </div>
                                                                    <div class="col-md-5">
                                                                        <input type="text" class="form-control" 
                                                                               name="step_header_value[<?= $index ?>][]" 
                                                                               placeholder="Header Value" 
                                                                               value="<?= htmlspecialchars($value) ?>">
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                        <button type="button" class="btn btn-danger w-100 remove-header">
                                                                            <i class="bi bi-trash"></i>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-12">
                                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                                            <h6 class="mb-0">数据提取规则</h6>
                                                            <button type="button" class="btn btn-sm btn-outline-primary add-rule" data-step-index="<?= $index ?>">
                                                                <i class="bi bi-plus"></i> 添加提取规则
                                                            </button>
                                                        </div>
                                                        <div class="rules-container mb-3">
                                                            <?php foreach ($step['extract_rules'] as $key => $rule): ?>
                                                                <div class="row g-2 mb-2 rule-row">
                                                                    <div class="col-md-5">
                                                                        <input type="text" class="form-control" 
                                                                               name="step_rule_key[<?= $index ?>][]" 
                                                                               placeholder="变量名" 
                                                                               value="<?= htmlspecialchars($key) ?>">
                                                                    </div>
                                                                    <div class="col-md-5">
                                                                        <input type="text" class="form-control" 
                                                                               name="step_rule_pattern[<?= $index ?>][]" 
                                                                               placeholder="正则表达式" 
                                                                               value="<?= htmlspecialchars($rule['pattern']) ?>">
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                        <button type="button" class="btn btn-danger w-100 remove-rule">
                                                                            <i class="bi bi-trash"></i>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div class="d-flex justify-content-between mt-3">
                                    <button type="button" class="btn btn-primary" id="addStepBtn">
                                        <i class="bi bi-plus-circle me-1"></i> 添加步骤
                                    </button>
                                </div>
                                
                                <div class="mb-3 mt-4">
                                    <label class="form-label fw-bold">输出模板</label>
                                    <textarea class="form-control" name="output_template" rows="3" required><?= htmlspecialchars($edit_task['output_template']) ?></textarea>
                                    <div class="form-text">
                                        使用 {{step_name.variable}} 格式引用提取的数据，例如: {{step1.title}}
                                    </div>
                                    
                                    <div class="mt-3">
                                        <label class="form-label fw-bold">模板预览:</label>
                                        <div class="preview-box">
                                            <?= htmlspecialchars($edit_task['output_template']) ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-grid mt-4">
                                    <button type="submit" class="btn btn-success btn-lg py-3">
                                        <i class="bi bi-save me-2"></i> 保存任务配置
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- 添加任务模态框 -->
    <div class="modal fade" id="addTaskModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">添加新任务</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label fw-bold">任务名称</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">任务描述</label>
                            <textarea class="form-control" name="description" rows="2"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">输出模板</label>
                            <textarea class="form-control" name="output_template" rows="3" required></textarea>
                            <div class="form-text">
                                使用 {{step_name.variable}} 格式引用提取的数据
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" class="btn btn-primary">创建任务</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 添加新步骤
        document.getElementById('addStepBtn')?.addEventListener('click', function() {
            const stepsContainer = document.getElementById('stepsContainer');
            const stepCount = stepsContainer.querySelectorAll('.step-card').length;
            const stepIndex = stepCount;
            
            const stepHtml = `
            <div class="step-card card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">步骤 ${stepIndex + 1}</h5>
                    <button type="button" class="btn btn-sm btn-danger remove-step">
                        <i class="bi bi-trash"></i> 删除
                    </button>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">步骤名称</label>
                            <input type="text" class="form-control" name="step_name[]" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">URL</label>
                            <input type="text" class="form-control" name="step_url[]" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">HTTP方法</label>
                            <select class="form-select" name="step_method[]">
                                <option value="GET">GET</option>
                                <option value="POST">POST</option>
                            </select>
                        </div>
                        
                        <div class="col-md-9">
                            <label class="form-label">请求体 (POST)</label>
                            <textarea class="form-control" name="step_body[]" rows="2"></textarea>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="mb-0">请求头</h6>
                                <button type="button" class="btn btn-sm btn-outline-primary add-header" data-step-index="${stepIndex}">
                                    <i class="bi bi-plus"></i> 添加请求头
                                </button>
                            </div>
                            <div class="headers-container mb-3">
                                <div class="row g-2 mb-2 header-row">
                                    <div class="col-md-5">
                                        <input type="text" class="form-control" 
                                               name="step_header_key[${stepIndex}][]" 
                                               placeholder="Header Key">
                                    </div>
                                    <div class="col-md-5">
                                        <input type="text" class="form-control" 
                                               name="step_header_value[${stepIndex}][]" 
                                               placeholder="Header Value">
                                    </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-danger w-100 remove-header">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="mb-0">数据提取规则</h6>
                                <button type="button" class="btn btn-sm btn-outline-primary add-rule" data-step-index="${stepIndex}">
                                    <i class="bi bi-plus"></i> 添加提取规则
                                </button>
                            </div>
                            <div class="rules-container mb-3">
                                <div class="row g-2 mb-2 rule-row">
                                    <div class="col-md-5">
                                        <input type="text" class="form-control" 
                                               name="step_rule_key[${stepIndex}][]" 
                                               placeholder="变量名">
                                    </div>
                                    <div class="col-md-5">
                                        <input type="text" class="form-control" 
                                               name="step_rule_pattern[${stepIndex}][]" 
                                               placeholder="正则表达式">
                                    </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-danger w-100 remove-rule">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            `;
            
            stepsContainer.insertAdjacentHTML('beforeend', stepHtml);
            
            // 初始化新添加步骤的事件
            const newStep = stepsContainer.lastElementChild;
            newStep.querySelector('.remove-step').addEventListener('click', function() {
                this.closest('.step-card').remove();
            });
            
            newStep.querySelector('.add-header').addEventListener('click', function() {
                const stepIndex = this.dataset.stepIndex;
                addHeaderField(stepIndex);
            });
            
            newStep.querySelector('.add-rule').addEventListener('click', function() {
                const stepIndex = this.dataset.stepIndex;
                addExtractRule(stepIndex);
            });
        });
        
        // 添加请求头字段
        function addHeaderField(stepIndex) {
            const container = document.querySelector(`button.add-header[data-step-index="${stepIndex}"]`).parentElement.nextElementSibling;
            
            const headerHtml = `
            <div class="row g-2 mb-2 header-row">
                <div class="col-md-5">
                    <input type="text" class="form-control" 
                           name="step_header_key[${stepIndex}][]" 
                           placeholder="Header Key">
                </div>
                <div class="col-md-5">
                    <input type="text" class="form-control" 
                           name="step_header_value[${stepIndex}][]" 
                           placeholder="Header Value">
                </div>
                <div class="col-md-2">
                    <button type="button" class="btn btn-danger w-100 remove-header">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
            `;
            
            container.insertAdjacentHTML('beforeend', headerHtml);
            
            // 添加删除事件
            container.querySelector('.header-row:last-child .remove-header').addEventListener('click', function() {
                this.closest('.header-row').remove();
            });
        }
        
        // 添加提取规则
        function addExtractRule(stepIndex) {
            const container = document.querySelector(`button.add-rule[data-step-index="${stepIndex}"]`).parentElement.nextElementSibling;
            
            const ruleHtml = `
            <div class="row g-2 mb-2 rule-row">
                <div class="col-md-5">
                    <input type="text" class="form-control" 
                           name="step_rule_key[${stepIndex}][]" 
                           placeholder="变量名">
                </div>
                <div class="col-md-5">
                    <input type="text" class="form-control" 
                           name="step_rule_pattern[${stepIndex}][]" 
                           placeholder="正则表达式">
                </div>
                <div class="col-md-2">
                    <button type="button" class="btn btn-danger w-100 remove-rule">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
            `;
            
            container.insertAdjacentHTML('beforeend', ruleHtml);
            
            // 添加删除事件
            container.querySelector('.rule-row:last-child .remove-rule').addEventListener('click', function() {
                this.closest('.rule-row').remove();
            });
        }
        
        // 初始化页面事件
        document.addEventListener('DOMContentLoaded', function() {
            // 删除步骤按钮
            document.querySelectorAll('.remove-step').forEach(btn => {
                btn.addEventListener('click', function() {
                    this.closest('.step-card').remove();
                });
            });
            
            // 添加请求头按钮
            document.querySelectorAll('.add-header').forEach(btn => {
                btn.addEventListener('click', function() {
                    const stepIndex = this.dataset.stepIndex;
                    addHeaderField(stepIndex);
                });
            });
            
            // 删除请求头按钮
            document.querySelectorAll('.remove-header').forEach(btn => {
                btn.addEventListener('click', function() {
                    this.closest('.header-row').remove();
                });
            });
            
            // 添加提取规则按钮
            document.querySelectorAll('.add-rule').forEach(btn => {
                btn.addEventListener('click', function() {
                    const stepIndex = this.dataset.stepIndex;
                    addExtractRule(stepIndex);
                });
            });
            
            // 删除提取规则按钮
            document.querySelectorAll('.remove-rule').forEach(btn => {
                btn.addEventListener('click', function() {
                    this.closest('.rule-row').remove();
                });
            });
        });
    </script>
</body>
</html>