// 添加新步骤
function addNewStep() {
    const stepsContainer = document.getElementById('stepsContainer');
    const stepCount = stepsContainer.querySelectorAll('.step-card').length;
    const stepIndex = stepCount;
    
    const stepHtml = `
    <div class="step-card card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">步骤 ${stepIndex + 1}</h5>
            <button type="button" class="btn btn-sm btn-danger remove-step">
                <i class="bi bi-trash"></i> 删除
            </button>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">步骤名称</label>
                    <input type="text" class="form-control" name="step_name[]" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">URL</label>
                    <input type="text" class="form-control" name="step_url[]" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">HTTP方法</label>
                    <select class="form-select" name="step_method[]">
                        <option value="GET">GET</option>
                        <option value="POST">POST</option>
                    </select>
                </div>
                
                <div class="col-md-9">
                    <label class="form-label">请求体 (POST)</label>
                    <textarea class="form-control" name="step_body[]" rows="2"></textarea>
                </div>
                
                <div class="col-md-12">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6 class="mb-0">请求头</h6>
                        <button type="button" class="btn btn-sm btn-outline-primary add-header" data-step-index="${stepIndex}">
                            <i class="bi bi-plus"></i> 添加请求头
                        </button>
                    </div>
                    <div class="headers-container mb-3">
                        <div class="row g-2 mb-2 header-row">
                            <div class="col-md-5">
                                <input type="text" class="form-control" 
                                       name="step_header_key[${stepIndex}][]" 
                                       placeholder="Header Key">
                            </div>
                            <div class="col-md-5">
                                <input type="text" class="form-control" 
                                       name="step_header_value[${stepIndex}][]" 
                                       placeholder="Header Value">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-danger w-100 remove-header">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6 class="mb-0">数据提取规则</h6>
                        <button type="button" class="btn btn-sm btn-outline-primary add-rule" data-step-index="${stepIndex}">
                            <i class="bi bi-plus"></i> 添加提取规则
                        </button>
                    </div>
                    <div class="rules-container mb-3">
                        <div class="row g-2 mb-2 rule-row">
                            <div class="col-md-5">
                                <input type="text" class="form-control" 
                                       name="step_rule_key[${stepIndex}][]" 
                                       placeholder="变量名">
                            </div>
                            <div class="col-md-5">
                                <input type="text" class="form-control" 
                                       name="step_rule_pattern[${stepIndex}][]" 
                                       placeholder="正则表达式">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-danger w-100 remove-rule">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `;
    
    stepsContainer.insertAdjacentHTML('beforeend', stepHtml);
    
    // 初始化新添加步骤的事件
    const newStep = stepsContainer.lastElementChild;
    initStepEvents(newStep);
}

// 初始化步骤事件
function initStepEvents(stepElement) {
    // 删除步骤按钮
    stepElement.querySelector('.remove-step').addEventListener('click', function() {
        this.closest('.step-card').remove();
    });
    
    // 添加请求头按钮
    stepElement.querySelector('.add-header').addEventListener('click', function() {
        const stepIndex = this.dataset.stepIndex;
        addHeaderField(stepIndex);
    });
    
    // 添加提取规则按钮
    stepElement.querySelector('.add-rule').addEventListener('click', function() {
        const stepIndex = this.dataset.stepIndex;
        addExtractRule(stepIndex);
    });
    
    // 删除请求头按钮
    stepElement.querySelectorAll('.remove-header').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.header-row').remove();
        });
    });
    
    // 删除提取规则按钮
    stepElement.querySelectorAll('.remove-rule').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.rule-row').remove();
        });
    });
}

// 添加请求头字段
function addHeaderField(stepIndex) {
    const container = document.querySelector(`button.add-header[data-step-index="${stepIndex}"]`).parentElement.nextElementSibling;
    
    const headerHtml = `
    <div class="row g-2 mb-2 header-row">
        <div class="col-md-5">
            <input type="text" class="form-control" 
                   name="step_header_key[${stepIndex}][]" 
                   placeholder="Header Key">
        </div>
        <div class="col-md-5">
            <input type="text" class="form-control" 
                   name="step_header_value[${stepIndex}][]" 
                   placeholder="Header Value">
        </div>
        <div class="col-md-2">
            <button type="button" class="btn btn-danger w-100 remove-header">
                <i class="bi bi-trash"></i>
            </button>
        </div>
    </div>
    `;
    
    container.insertAdjacentHTML('beforeend', headerHtml);
    
    // 添加删除事件
    container.querySelector('.header-row:last-child .remove-header').addEventListener('click', function() {
        this.closest('.header-row').remove();
    });
}

// 添加提取规则
function addExtractRule(stepIndex) {
    const container = document.querySelector(`button.add-rule[data-step-index="${stepIndex}"]`).parentElement.nextElementSibling;
    
    const ruleHtml = `
    <div class="row g-2 mb-2 rule-row">
        <div class="col-md-5">
            <input type="text" class="form-control" 
                   name="step_rule_key[${stepIndex}][]" 
                   placeholder="变量名">
        </div>
        <div class="col-md-5">
            <input type="text" class="form-control" 
                   name="step_rule_pattern[${stepIndex}][]" 
                   placeholder="正则表达式">
        </div>
        <div class="col-md-2">
            <button type="button" class="btn btn-danger w-100 remove-rule">
                <i class="bi bi-trash"></i>
            </button>
        </div>
    </div>
    `;
    
    container.insertAdjacentHTML('beforeend', ruleHtml);
    
    // 添加删除事件
    container.querySelector('.rule-row:last-child .remove-rule').addEventListener('click', function() {
        this.closest('.rule-row').remove();
    });
}

// 初始化页面事件
document.addEventListener('DOMContentLoaded', function() {
    // 添加步骤按钮
    document.getElementById('addStepBtn')?.addEventListener('click', addNewStep);
    
    // 初始化现有步骤的事件
    document.querySelectorAll('.step-card').forEach(step => {
        initStepEvents(step);
    });
});