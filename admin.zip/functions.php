<?php
require_once 'db.php';

// 执行SQL文件
function execute_sql_file($file_path) {
    global $conn;
    
    // 读取SQL文件内容
    $sql = file_get_contents($file_path);
    
    if (!$sql) {
        return false;
    }
    
    // 执行多条SQL语句
    if ($conn->multi_query($sql)) {
        do {
            // 清空结果
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->more_results() && $conn->next_result());
    }
    
    return true;
}

// 执行爬虫任务
function execute_crawler_task($task_id, $input) {
    global $conn;
    
    // 获取任务配置
    $task_sql = "SELECT * FROM crawler_tasks WHERE id = $task_id";
    $task_result = $conn->query($task_sql);
    
    if (!$task_result || $task_result->num_rows === 0) {
        return array('error' => '任务不存在');
    }
    
    $task = $task_result->fetch_assoc();
    $steps = json_decode($task['steps'], true);
    
    $results = array();
    $context = array('input' => $input);
    
    foreach ($steps as $step) {
        $url = $step['url'];
        $method = strtoupper($step['method']);
        $headers = $step['headers'];
        $body = $step['body'];
        $extract_rules = $step['extract_rules'];
        
        // 替换变量
        $url = replace_variables($url, $context);
        $body = replace_variables($body, $context);
        
        // 执行请求
        $response = execute_request($url, $method, $headers, $body);
        
        if (isset($response['error'])) {
            return $response;
        }
        
        // 提取数据
        $extracted_data = extract_data($response['content'], $extract_rules);
        
        // 保存到上下文供后续步骤使用
        $context[$step['name']] = $extracted_data;
        
        // 保存结果
        $results[$step['name']] = array(
            'response' => $response,
            'extracted' => $extracted_data
        );
    }
    
    // 获取最终输出
    $final_output = replace_variables($task['output_template'], $context);
    
    // 保存到数据库
    $insert_sql = "INSERT INTO query_results (task_id, input, output) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("iss", $task_id, $input, $final_output);
    $stmt->execute();
    
    return array(
        'output' => $final_output,
        'steps' => $results
    );
}

// 替换变量
function replace_variables($string, $context) {
    preg_match_all('/\{\{([^\}]+)\}\}/', $string, $matches);
    
    foreach ($matches[1] as $var) {
        $value = get_nested_value($context, $var);
        $string = str_replace('{{'.$var.'}}', $value, $string);
    }
    
    return $string;
}

// 获取嵌套值
function get_nested_value($array, $key) {
    $keys = explode('.', $key);
    $value = $array;
    
    foreach ($keys as $k) {
        if (isset($value[$k])) {
            $value = $value[$k];
        } else {
            return '';
        }
    }
    
    return is_array($value) ? json_encode($value) : $value;
}

// 执行HTTP请求
function execute_request($url, $method = 'GET', $headers = array(), $body = '') {
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    
    if (!empty($headers)) {
        $header_array = array();
        foreach ($headers as $key => $value) {
            $header_array[] = "$key: $value";
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header_array);
    }
    
    $content = curl_exec($ch);
    $info = curl_getinfo($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return array('error' => "cURL错误: $error");
    }
    
    if ($info['http_code'] !== 200) {
        return array('error' => "HTTP错误: {$info['http_code']}");
    }
    
    return array(
        'content' => $content,
        'info' => $info
    );
}

// 提取数据
function extract_data($content, $rules) {
    $result = array();
    
    foreach ($rules as $key => $rule) {
        if ($rule['type'] === 'regex') {
            preg_match($rule['pattern'], $content, $matches);
            $result[$key] = $matches[1] ?? '';
        } 
        // 可以扩展其他提取方法如XPath, JSON等
    }
    
    return $result;
}
?>