<?php
require_once 'functions.php';

// 获取所有任务
$tasks = array();
$sql = "SELECT id, name FROM crawler_tasks";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }
}

// 处理查询请求
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['query'])) {
    $task_id = intval($_POST['task_id']);
    $input = trim($_POST['input']);
    
    if ($task_id > 0 && !empty($input)) {
        $result = execute_crawler_task($task_id, $input);
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据查询系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            min-height: 100vh;
            padding-top: 30px;
            padding-bottom: 50px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            border: none;
            overflow: hidden;
        }
        .card-header {
            background: linear-gradient(90deg, #2c3e50, #4a6491);
            color: white;
            font-weight: bold;
            padding: 20px;
        }
        .result-card {
            background: rgba(255, 255, 255, 0.95);
            border-left: 5px solid #3498db;
        }
        .step-card {
            background: rgba(240, 248, 255, 0.9);
            border-left: 4px solid #2ecc71;
            margin-bottom: 20px;
        }
        .pre-container {
            max-height: 300px;
            overflow: auto;
            background: #2c3e50;
            color: #ecf0f1;
            border-radius: 8px;
            padding: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8">
                <div class="card mb-5">
                    <div class="card-header text-center">
                        <h1 class="mb-0">数据查询系统</h1>
                        <p class="mb-0">多步骤爬虫数据查询平台</p>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" class="mb-4">
                            <div class="row g-3">
                                <div class="col-md-5">
                                    <label for="taskSelect" class="form-label fw-bold">选择查询任务</label>
                                    <select class="form-select form-select-lg" id="taskSelect" name="task_id" required>
                                        <option value="">-- 请选择任务 --</option>
                                        <?php foreach ($tasks as $task): ?>
                                            <option value="<?= $task['id'] ?>"><?= htmlspecialchars($task['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-7">
                                    <label for="queryInput" class="form-label fw-bold">输入查询内容</label>
                                    <div class="input-group input-group-lg">
                                        <input type="text" class="form-control" id="queryInput" 
                                               name="input" placeholder="输入查询关键词..." required>
                                        <button class="btn btn-primary" type="submit" name="query">
                                            <i class="bi bi-search me-1"></i> 查询
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        
                        <?php if ($result): ?>
                            <div class="card result-card mt-4">
                                <div class="card-header bg-success text-white">
                                    <h3 class="mb-0">查询结果</h3>
                                </div>
                                <div class="card-body">
                                    <?php if (isset($result['error'])): ?>
                                        <div class="alert alert-danger">
                                            <h4><i class="bi bi-exclamation-triangle-fill"></i> 错误发生</h4>
                                            <p class="mb-0"><?= htmlspecialchars($result['error']) ?></p>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-success">
                                            <h4><i class="bi bi-check-circle-fill"></i> 查询成功</h4>
                                            <p class="mb-0"><strong>最终结果:</strong> <?= htmlspecialchars($result['output']) ?></p>
                                        </div>
                                        
                                        <div class="mt-4">
                                            <h4 class="mb-3 border-bottom pb-2">执行步骤详情</h4>
                                            <?php foreach ($result['steps'] as $step_name => $step): ?>
                                                <div class="card step-card mb-4">
                                                    <div class="card-header bg-info text-white">
                                                        步骤: <?= htmlspecialchars($step_name) ?>
                                                    </div>
                                                    <div class="card-body">
                                                        <h5>提取数据:</h5>
                                                        <div class="pre-container">
                                                            <pre><?= htmlspecialchars(print_r($step['extracted'], true)) ?></pre>
                                                        </div>
                                                        
                                                        <h5 class="mt-3">响应详情:</h5>
                                                        <div class="pre-container">
                                                            <pre><?= htmlspecialchars(print_r($step['response'], true)) ?></pre>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="text-center text-white mt-4">
                    <p>爬虫查询系统 &copy; 2023 | 支持多步骤请求与数据提取</p>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>